public class Meat extends Food{
    public Meat(){
    }

    public int getPower(){
        return 50;
    }
}
